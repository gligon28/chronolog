import Foundation

struct Activity {
    let name: String
    var isSelected: Bool
}
